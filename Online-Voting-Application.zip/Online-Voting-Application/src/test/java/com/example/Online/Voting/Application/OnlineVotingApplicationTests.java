package com.example.Online.Voting.Application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineVotingApplicationTests {

	@Test
	void contextLoads() {
	}

}
