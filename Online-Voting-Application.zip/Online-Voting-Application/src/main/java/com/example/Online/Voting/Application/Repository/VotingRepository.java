package com.example.Online.Voting.Application.Repository;

import com.example.Online.Voting.Application.Entity.Voting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VotingRepository extends JpaRepository<Voting, Long> {
    Optional<Voting> findByVoterId(Long voterId);

    @Query("SELECT COUNT(v) FROM Voting v WHERE v.candidateId = :candidateId")
    Long countVotesByCandidateId(Long candidateId);

    @Query("SELECT COUNT(v) FROM Voting v")
    Long countTotalVotes();
}