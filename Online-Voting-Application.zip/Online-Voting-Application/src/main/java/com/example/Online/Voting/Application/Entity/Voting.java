package com.example.Online.Voting.Application.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Voting")
public class Voting{

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "voter_id")
    private long voterId;

    @Column(name = "candidate_id")
    private long candidateId;

    public Voting(){}

    public Voting(long voterId, long candidateId) {
        this.voterId = voterId;
        this.candidateId = candidateId;
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getVoterId() {
        return voterId;
    }

    public void setVoterId(int voterId) {
        this.voterId = voterId;
    }

    public long getCandidateId() {
        return candidateId;
    }

    public void setCandidateId(int candidateId) {
        this.candidateId = candidateId;
    }
}
