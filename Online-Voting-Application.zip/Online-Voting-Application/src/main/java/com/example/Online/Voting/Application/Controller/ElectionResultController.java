package com.example.Online.Voting.Application.Controller;

import com.example.Online.Voting.Application.Entity.Candidate;
import com.example.Online.Voting.Application.Entity.ElectionResult;
import com.example.Online.Voting.Application.Service.ElectionResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/results")
@CrossOrigin(origins = "*")
public class ElectionResultController {

    @Autowired
    private ElectionResultService electionResultService;

    @PostMapping("/calculate")
    public ResponseEntity<ElectionResult> calculateResults() {
        try {
            ElectionResult result = electionResultService.calculateResults();
            return ResponseEntity.ok(result);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/final")
    public ResponseEntity<ElectionResult> getFinalizedResult() {
        Optional<ElectionResult> result = electionResultService.getFinalizedResult();
        return result.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/live")
    public ResponseEntity<List<Candidate>> getLiveResults() {
        return ResponseEntity.ok(electionResultService.getLiveResults());
    }
}
