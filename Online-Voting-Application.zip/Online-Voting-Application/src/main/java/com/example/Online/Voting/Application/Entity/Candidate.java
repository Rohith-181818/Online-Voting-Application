package com.example.Online.Voting.Application.Entity;

import jakarta.annotation.Nullable;
import jakarta.persistence.*;

@Entity
@Table(name = "candidates")
public class Candidate{

    @Id
    @Column(name = "candidate_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "candidate_name")
    private String candidateName;

    @Column(name = "candidate_party")
    private String party;

    @Column(name = "vote_count")
    private Integer voteCount = 0;

    @Column(name = "active", nullable = false)
    private Boolean active = true;

    public Candidate(){}

    public Candidate(String candidateName, String party, Integer voteCount, Boolean active) {
        this.candidateName = candidateName;
        this.party = party;
        this.voteCount = voteCount;
        this.active = active;
    }

    public Long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = (long) id;
    }

    public String getCandidateName() {
        return candidateName;
    }

    public void setCandidateName(String name) {
        this.candidateName = name;
    }

    public String getParty() {
        return party;
    }

    public void setParty(String party) {
        this.party = party;
    }

    public Integer getVoteCount() {
        return voteCount;
    }

    public void setVoteCount(Integer count) {
        this.voteCount = count;
    }

    public boolean getActive() {
        return active;
    }
}
