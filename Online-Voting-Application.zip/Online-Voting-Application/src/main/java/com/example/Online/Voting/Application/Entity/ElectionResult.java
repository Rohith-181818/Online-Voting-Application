package com.example.Online.Voting.Application.Entity;

import jakarta.persistence.*;

@Entity
@Table(name = "Election_Results")
public class ElectionResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "winner_id")
    private long winnerId;

    @Column(name = "winner_name")
    private String winnerName;

    @Column(name = "total_votes")
    private Integer totalVotes;

    @Column(name = "final")
    private boolean isFinalized = true;

    public ElectionResult() {}

    public ElectionResult(int winnerId, String winnerName, int totalVotes, boolean isFinalized) {
        this.winnerId = winnerId;
        this.winnerName = winnerName;
        this.totalVotes = totalVotes;
        this.isFinalized = isFinalized;
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public long getWinnerId() {
        return winnerId;
    }

    public void setWinnerId(int winnerId) {
        this.winnerId = winnerId;
    }

    public String getWinnerName() {
        return winnerName;
    }

    public void setWinnerName(String winnerName) {
        this.winnerName = winnerName;
    }

    public Integer getTotalVotes() {
        return totalVotes;
    }

    public void setTotalVotes(int votes) {
        this.totalVotes = votes;
    }

    public boolean isFinalized() {
        return isFinalized;
    }

    public void setIsFinalized(boolean b) {
        this.isFinalized = b;
    }
}

