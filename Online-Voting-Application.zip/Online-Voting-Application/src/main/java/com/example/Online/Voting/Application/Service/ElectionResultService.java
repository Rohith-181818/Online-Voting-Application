package com.example.Online.Voting.Application.Service;

import com.example.Online.Voting.Application.Entity.Candidate;
import com.example.Online.Voting.Application.Entity.ElectionResult;
import com.example.Online.Voting.Application.Repository.ElectionResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ElectionResultService {

    @Autowired
    private ElectionResultRepository electionResultRepository;

    @Autowired
    private CandidateService candidateService;

    @Autowired
    private VotingService votingService;

    public ElectionResult calculateResults() {
        List<Candidate> winners = candidateService.getWinningCandidates();

        if (winners.isEmpty()) {
            throw new RuntimeException("No candidates found");
        }

        Candidate winner = winners.getFirst();
        Long totalVotes = votingService.getTotalVotes();

        ElectionResult result = new ElectionResult();
        result.setWinnerId(Math.toIntExact(winner.getId()));
        result.setWinnerName(winner.getCandidateName());
        result.setTotalVotes(totalVotes.intValue());
        result.setIsFinalized(true);

        return electionResultRepository.save(result);
    }

    public Optional<ElectionResult> getFinalizedResult() {
        return electionResultRepository.findByIsFinalizedTrue();
    }

    public List<Candidate> getLiveResults() {
        return candidateService.getCandidatesByVoteCount();
    }
}