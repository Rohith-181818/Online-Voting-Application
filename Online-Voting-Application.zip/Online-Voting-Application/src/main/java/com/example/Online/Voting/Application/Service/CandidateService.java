package com.example.Online.Voting.Application.Service;

import com.example.Online.Voting.Application.Entity.Candidate;
import com.example.Online.Voting.Application.Repository.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    public Candidate registerCandidate(Candidate candidate) {
        return candidateRepository.save(candidate);
    }


    public List<Candidate> getAllCandidates() {
        return candidateRepository.findAll();
    }

    @Cacheable("candidates")
    public List<Candidate> getActiveCandidates() {
        return candidateRepository.findByActiveTrue();
    }

    @Cacheable("candidates")
    public Optional<Candidate> getCandidateById(Long id) {
        return candidateRepository.findById(id);
    }

    public void incrementVoteCount(Long candidateId) {
        Optional<Candidate> candidate = candidateRepository.findById(candidateId);
        if (candidate.isPresent()) {
            candidate.get().setVoteCount(candidate.get().getVoteCount() + 1);
            candidateRepository.save(candidate.get());
        }
    }

    @Cacheable("candidate")
    public List<Candidate> getCandidatesByVoteCount() {
        return candidateRepository.findActiveCandidatesOrderByVoteCountDesc();
    }

    public List<Candidate> getWinningCandidates() {
        return candidateRepository.findWinningCandidates();
    }
}
