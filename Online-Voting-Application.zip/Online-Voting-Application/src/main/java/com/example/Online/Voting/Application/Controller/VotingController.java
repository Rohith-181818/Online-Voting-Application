package com.example.Online.Voting.Application.Controller;

import com.example.Online.Voting.Application.Service.VotingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/voting")
@CrossOrigin(origins = "*")
public class VotingController {

    @Autowired
    private VotingService votingService;

    @PostMapping("/cast")
    public ResponseEntity<String> castVote(@RequestParam Long voterId, @RequestParam Long candidateId) {
        String result = votingService.castVote(voterId, candidateId);
        if (result.equals("Vote cast successfully")) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.badRequest().body(result);
        }
    }

    @GetMapping("/total")
    public ResponseEntity<Long> getTotalVotes() {
        return ResponseEntity.ok(votingService.getTotalVotes());
    }

    @GetMapping("/candidate/{candidateId}")
    public ResponseEntity<Long> getVotesForCandidate(@PathVariable Long candidateId) {
        return ResponseEntity.ok(votingService.getVotesForCandidate(candidateId));
    }

    @GetMapping("/voter/{voterId}/status")
    public ResponseEntity<Boolean> hasVoterVoted(@PathVariable Long voterId) {
        return ResponseEntity.ok(votingService.hasVoterVoted(voterId));
    }
}