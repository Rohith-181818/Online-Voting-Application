package com.example.Online.Voting.Application.Repository;

import com.example.Online.Voting.Application.Entity.Voter;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VoterRepository extends JpaRepository<Voter, Long> {
    Optional<Voter> findByVoterEmail(String voterEmail);

    Optional<Voter> findByVoterName(String voterName);

    @Query("SELECT COUNT(v) FROM Voter v WHERE v.hasVoted = true")
    Long countVotedVoters();

    @Query("SELECT COUNT(v) FROM Voter v WHERE v.active = true")
    Long countActiveVoters();
}
