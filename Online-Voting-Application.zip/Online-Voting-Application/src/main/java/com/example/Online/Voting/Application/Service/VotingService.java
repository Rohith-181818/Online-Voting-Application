package com.example.Online.Voting.Application.Service;

import com.example.Online.Voting.Application.Entity.Candidate;
import com.example.Online.Voting.Application.Entity.Voter;
import com.example.Online.Voting.Application.Entity.Voting;
import com.example.Online.Voting.Application.Repository.VotingRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class VotingService {

    @Autowired
    private VotingRepository votingRepository;

    @Autowired
    private VoterService voterService;

    @Autowired
    private CandidateService candidateService;

    @Transactional
    public String castVote(Long voterId, Long candidateId) {
        // Check if voter exists and is active
        Optional<Voter> voter = voterService.getVoterById(voterId);
        if (voter.isEmpty() || !voter.get().getActive()) {
            return "Voter not found or inactive";
        }

        // Check if voter has already voted
        if (voter.get().getHasVoted()) {
            return "Voter has already voted";
        }

        // Check if candidate exists and is active
        Optional<Candidate> candidate = candidateService.getCandidateById(candidateId);
        if (candidate.isEmpty() || !candidate.get().getActive()) {
            return "Candidate not found or inactive";
        }

        // Create voting record
        Voting voting = new Voting();
        voting.setVoterId(Math.toIntExact(voterId));
        voting.setCandidateId(Math.toIntExact(candidateId));
        votingRepository.save(voting);

        // Mark voter as voted
        voterService.markVoterAsVoted(voterId);

        // Increment candidate vote count
        candidateService.incrementVoteCount(candidateId);

        return "Vote cast successfully";
    }

    public Long getTotalVotes() {
        return votingRepository.countTotalVotes();
    }

    public Long getVotesForCandidate(Long candidateId) {
        return votingRepository.countVotesByCandidateId(candidateId);
    }

    public boolean hasVoterVoted(Long voterId) {
        return votingRepository.findByVoterId(voterId).isPresent();
    }
}