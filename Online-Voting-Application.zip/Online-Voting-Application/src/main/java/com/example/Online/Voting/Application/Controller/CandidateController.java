package com.example.Online.Voting.Application.Controller;

import com.example.Online.Voting.Application.Entity.Candidate;
import com.example.Online.Voting.Application.Service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/candidates")
@CrossOrigin(origins = "*")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @PostMapping("/register")
    public ResponseEntity<Candidate> registerCandidate(@RequestBody Candidate candidate) {
        Candidate savedCandidate = candidateService.registerCandidate(candidate);
        return ResponseEntity.ok(savedCandidate);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Candidate>> getAllCandidates() {
        return ResponseEntity.ok(candidateService.getAllCandidates());
    }

    @GetMapping("/active")
    public ResponseEntity<List<Candidate>> getActiveCandidates() {
        return ResponseEntity.ok(candidateService.getActiveCandidates());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Candidate> getCandidateById(@PathVariable Long id) {
        Optional<Candidate> candidate = candidateService.getCandidateById(id);
        return candidate.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/results")
    public ResponseEntity<List<Candidate>> getCandidatesByVoteCount() {
        return ResponseEntity.ok(candidateService.getCandidatesByVoteCount());
    }
}

