package com.example.Online.Voting.Application.Entity;

import jakarta.annotation.Nullable;
import jakarta.persistence.*;

@Entity
@Table(name = "Voters")
public class Voter{

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "voter_name")
    private String voterName;


    @Column(unique = true, name = "voter_email", nullable = false)
    private String voterEmail;

    @Column(name = "hasVoted")
    private Boolean hasVoted = false;

    @Column(name = "active")
    private Boolean active = true;

    public Voter(){}

    public Voter(String voterName, String voterEmail, Boolean hasVoted, Boolean active) {
        this.voterName = voterName;
        this.voterEmail = voterEmail;
        this.hasVoted = hasVoted;
        this.active = active;
    }

    public int getId() {
        return Math.toIntExact(id);
    }

    public void setId(int id) {
        this.id = (long) id;
    }

    public String getVoterName() {
        return voterName;
    }

    public void setVoterName(String voterName) {
        this.voterName = voterName;
    }

    public String getVoterEmail() {
        return voterEmail;
    }

    public void setVoterEmail(String voterEmail) {
        this.voterEmail = voterEmail;
    }

    public boolean isHasVoted() {
        return hasVoted;
    }

    public void setHasVoted(boolean hasVoted) {
        this.hasVoted = hasVoted;
    }

    public String getEmail() {
        return voterEmail;
    }


    public boolean getHasVoted() {
        return hasVoted;
    }

    public boolean getActive() {
        return active;
    }
}


