package com.example.Online.Voting.Application.Repository;

import com.example.Online.Voting.Application.Entity.Candidate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CandidateRepository extends JpaRepository<Candidate, Long> {

    List<Candidate> findByActiveTrue();

    @Query("SELECT c FROM Candidate c WHERE c.active = true ORDER BY c.voteCount DESC")
    List<Candidate> findActiveCandidatesOrderByVoteCountDesc();

    @Query("SELECT c FROM Candidate c WHERE c.voteCount = (SELECT MAX(c2.voteCount) FROM Candidate c2 WHERE c2.active = true)")
    List<Candidate> findWinningCandidates();
}
