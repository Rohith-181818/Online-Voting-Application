package com.example.Online.Voting.Application.Controller;

import com.example.Online.Voting.Application.Entity.Voter;
import com.example.Online.Voting.Application.Service.VoterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/voters")
@CrossOrigin(origins = "*")
public class VoterController {

    @Autowired
    private VoterService voterService;

    @PostMapping("/register")
    public ResponseEntity<?> registerVoter(@RequestBody Voter voter) {
        try {
            Voter savedVoter = voterService.registerVoter(voter);
            return ResponseEntity.ok(savedVoter);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<List<Voter>> getAllVoters() {
        return ResponseEntity.ok(voterService.getAllVoters());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Voter> getVoterById(@PathVariable Long id) {
        Optional<Voter> voter = voterService.getVoterById(id);
        return voter.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<Voter> getVoterByEmail(@PathVariable String email) {
        Optional<Voter> voter = voterService.getVoterByEmail(email);
        return voter.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/stats/voted")
    public ResponseEntity<Long> getVotedVotersCount() {
        return ResponseEntity.ok(voterService.getVotedVotersCount());
    }

    @GetMapping("/stats/active")
    public ResponseEntity<Long> getActiveVotersCount() {
        return ResponseEntity.ok(voterService.getActiveVotersCount());
    }
}

