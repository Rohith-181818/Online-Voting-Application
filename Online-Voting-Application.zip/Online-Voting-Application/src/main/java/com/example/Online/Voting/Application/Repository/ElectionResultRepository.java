package com.example.Online.Voting.Application.Repository;

import com.example.Online.Voting.Application.Entity.ElectionResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ElectionResultRepository extends JpaRepository<ElectionResult, Long> {
    Optional<ElectionResult> findByIsFinalizedTrue();
}
