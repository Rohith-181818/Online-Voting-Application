package com.example.Online.Voting.Application.Service;

import com.example.Online.Voting.Application.Entity.Voter;
import com.example.Online.Voting.Application.Repository.VoterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VoterService {

    @Autowired
    private VoterRepository voterRepository;

    public Voter registerVoter(Voter voter) {
        // Check if voter already exists
        Optional<Voter> existingVoter = voterRepository.findByVoterEmail(voter.getEmail());
        if (existingVoter.isPresent()) {
            throw new RuntimeException("Voter with this email already exists");
        }
        return voterRepository.save(voter);
    }

    @Cacheable("voters")
    public List<Voter> getAllVoters() {
        return voterRepository.findAll();
    }

    @Cacheable("voters")
    public Optional<Voter> getVoterById(Long id) {
        return voterRepository.findById(id);
    }

    @Cacheable("voters")
    public Optional<Voter> getVoterByName(String name){
        return voterRepository.findByVoterName(name);
    }

    @Cacheable("voters")
    public Optional<Voter> getVoterByEmail(String email) {
        return voterRepository.findByVoterEmail(email);
    }

    public void markVoterAsVoted(Long voterId) {
        Optional<Voter> voter = voterRepository.findById(voterId);
        if (voter.isPresent()) {
            voter.get().setHasVoted(true);
            voterRepository.save(voter.get());
        }
    }

    @Cacheable("voters")
    public Long getVotedVotersCount() {
        return voterRepository.countVotedVoters();
    }

    @Cacheable("voters")
    public Long getActiveVotersCount() {
        return voterRepository.countActiveVoters();
    }
}